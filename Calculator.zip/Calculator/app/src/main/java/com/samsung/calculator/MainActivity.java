package com.samsung.calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.view.View.OnClickListener;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button button_0, button_1, button_2, button_3, button_4, button_5, button_6, button_7, button_8, button_9;
    Button button_C, button_CE, button_delete, button_comma, button_plus, button_minus,button_reverse,button_division,button_multiplication,button_equal;
    String input = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView result = findViewById(R.id.result);
        button_0 = (Button) findViewById(R.id.button_0);
        button_1 = (Button) findViewById(R.id.button_1);
        button_2 = (Button) findViewById(R.id.button_2);
        button_3 = (Button) findViewById(R.id.button_3);
        button_4 = (Button) findViewById(R.id.button_4);
        button_5 = (Button) findViewById(R.id.button_5);
        button_6 = (Button) findViewById(R.id.button_6);
        button_7 = (Button) findViewById(R.id.button_7);
        button_8 = (Button) findViewById(R.id.button_8);
        button_9 = (Button) findViewById(R.id.button_9);
        button_CE = (Button) findViewById(R.id.button_CE);
        button_C = findViewById(R.id.button_C);
        button_delete = findViewById(R.id.button_delete);
        button_plus = findViewById(R.id.button_plus);
        button_minus = findViewById(R.id.button_minus);
        button_multiplication = findViewById(R.id.button_multiplication);
        button_division = findViewById(R.id.button_division);
        button_comma = findViewById(R.id.button_comma);
        button_reverse = findViewById(R.id.button_reverse);
        button_equal = findViewById(R.id.button_equal);
        OnClickListener action = new OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = v.getId();
                String ABC = "0123456789";
                if (a==R.id.button_1){
                    input = input + "1";
                    result.setText(input);
                }
                if (a==R.id.button_2){
                    input = input + "2";
                    result.setText(input);
                }
                if (a==R.id.button_3){
                    input = input + "3";
                    result.setText(input);
                }
                if (a==R.id.button_4){
                    input = input + "4";
                    result.setText(input);
                }
                if (a==R.id.button_5){
                    input = input + "5";
                    result.setText(input);
                }
                if (a==R.id.button_6){
                    input = input + "6";
                    result.setText(input);
                }
                if (a==R.id.button_7){
                    input = input + "7";
                    result.setText(input);
                }
                if (a==R.id.button_8){
                    input = input + "8";
                    result.setText(input);
                }
                if (a==R.id.button_9){
                    input = input + "9";
                    result.setText(input);
                }
                if (a==R.id.button_0){
                    input = input + "0";
                    result.setText(input);


                }
                if (a==R.id.button_C){
                    input = "";
                    result.setText(input);
                }
                if (a==R.id.button_CE){
                    input = "";
                    result.setText(input);
                }
                if (a==R.id.button_C){
                    input = "";
                    result.setText(input);
                }
                if(a==R.id.button_delete){
                    if(!input.isEmpty()){
                        input = input.substring(0,input.length()-1);
                        result.setText(input);
                    }
                }
                if (!input.isEmpty()){
                    char last = input.charAt(input.length()-1);
                    if (ABC.contains(String.valueOf(last))){
                        if(a==R.id.button_plus){
                            input = input + " " + "+" + " ";
                            result.setText(input);
                        }
                        if(a==R.id.button_minus){
                            input = input + " " + "-" + " ";
                            result.setText(input);
                        }
                        if(a==R.id.button_multiplication){
                            input = input + " " + "*" + " ";
                            result.setText(input);
                        }
                        if(a==R.id.button_division){
                            input = input + " " + "÷" + " ";
                            result.setText(input);
                        }
                        if(a==R.id.button_comma){
                            input = input + "." ;
                            result.setText(input);
                        }
                    }
                }

            }
        };
        button_1.setOnClickListener(action);
        button_2.setOnClickListener(action);
        button_3.setOnClickListener(action);
        button_4.setOnClickListener(action);
        button_5.setOnClickListener(action);
        button_6.setOnClickListener(action);
        button_7.setOnClickListener(action);
        button_8.setOnClickListener(action);
        button_9.setOnClickListener(action);
        button_0.setOnClickListener(action);
        button_CE.setOnClickListener(action);
        button_C.setOnClickListener(action);
        button_delete.setOnClickListener(action);
        button_plus.setOnClickListener(action);
        button_minus.setOnClickListener(action);
        button_division.setOnClickListener(action);
        button_multiplication.setOnClickListener(action);
        button_comma.setOnClickListener(action);
        button_reverse.setOnClickListener(action);

        OnClickListener calculate = new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!"0123456789.".contains(String.valueOf(input.charAt(input.length()-1)))){
                    input = input.substring(0,input.length()-3);
                    result.setText(input);
                }
                String [] array = input.split(" ");
                while(array.length > 1) {
                    while (input.contains("*") || input.contains("÷")) {
                        for (int i = 0; i < array.length; i++) {
                            if (array[i].equals("÷") || array[i].equals("*")) {
                                double a = Calculate(Double.parseDouble(array[i - 1]), array[i], Double.parseDouble(array[i + 1]));
                                input = "";
                                for (int j = 0; j < array.length; j++) {
                                    if (j != i - 1 && j != i + 1) {
                                        if (j == i) {
                                            if (!input.isEmpty()) {
                                                input = input + " " + a;
                                            } else {
                                                input = input + a;
                                            }

                                        } else {
                                            if (!input.isEmpty()) {
                                                input = input + " " + array[j];
                                            } else {
                                                input = input + array[j];
                                            }

                                        }
                                    }
                                }
                                array = input.split(" ");
                            }
                        }
                    }
                    array = input.split(" ");
                    double answer = Double.parseDouble(array[0]);
                    for(int i = 1; i < array.length; i+=2){
                        answer = Calculate((Double) answer, array[i], Double.parseDouble(array[i+1]));
                    }
                    input = String.valueOf(answer);
                    array = input.split(" ");
                }

                if (isInteger(input)){
                    input = String.valueOf((int) Double.parseDouble(input));
                }
                result.setText(input);
            }
        };
        button_equal.setOnClickListener(calculate);
    }
    public static boolean isInteger(String x){
        return Double.parseDouble(x) == (int) Double.parseDouble(x);
    }
    public static double Calculate(double x,String sign, double y){
        switch (sign){
            case "+":
                return x+y;
            case "-":
                return x-y;
            case "*":
                return x*y;
            case "÷":
                return x/y;
            case "%":
                return x%y;
            case "//":
                return x/y-(x/y)%1;

            default:
                System.out.println("Error");
                return 0;
        }
    }
}
